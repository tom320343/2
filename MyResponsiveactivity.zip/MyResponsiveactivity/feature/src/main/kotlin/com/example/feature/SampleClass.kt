package com.example.feature

/**
 * Sample class for the feature module.
 */
class SampleClass {
    
    /**
     * Sample method that returns a greeting message.
     */
    fun getGreeting(): String {
        return "Hello from feature module!"
    }
}